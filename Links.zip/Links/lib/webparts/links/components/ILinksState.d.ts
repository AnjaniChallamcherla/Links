/// <reference types="react" />
import { tempArray } from './Interfaces/IUrl';
export interface ILinksState {
    showPanel: boolean;
    slider: number;
    lay: string;
    Data: JSX.Element;
    compactArr: tempArray[];
    listArr: tempArray[];
    tilesArr: tempArray[];
    showNewPanel: boolean;
    sliderDis: boolean;
}
