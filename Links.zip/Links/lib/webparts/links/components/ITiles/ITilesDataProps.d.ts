import { tempArray } from '../Interfaces/IUrl';
export interface ITilesDataProps {
    tilesBack: (event: any) => void;
    tilesNext: (event: any) => void;
    arr1: tempArray[];
    oldT: number;
    valT: number;
    btntilesNext: boolean;
    btntilesBack: boolean;
    tilesDel: (event, even, eve: any) => void;
    siteUrl: string;
    imgUrl: string;
    userPerm: boolean;
}
