declare const styles: {
    div1: string;
    img1: string;
    p1: string;
    tilesA: string;
    dis: string;
    edi: string;
    del: string;
    roww1: string;
    columnn1: string;
    column3: string;
    column2: string;
    nextArrow: string;
    backArrow: string;
};
export default styles;
