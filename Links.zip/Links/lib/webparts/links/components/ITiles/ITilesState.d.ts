export interface ITilesState {
    showEditPanel: boolean;
    hideDialog: boolean;
}
