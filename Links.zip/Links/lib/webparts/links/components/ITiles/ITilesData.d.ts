/// <reference types="react" />
import * as React from 'react';
import { ITilesDataProps } from './ITilesDataProps';
import { ITilesState } from './ITilesState';
export default class TilesData extends React.Component<ITilesDataProps, ITilesState> {
    constructor(props: any);
    render(): React.ReactElement<ITilesDataProps>;
    private ed(e);
    private editLink();
    private del(e);
    private delItem();
    private imgChange();
    private _closeDialog;
}
