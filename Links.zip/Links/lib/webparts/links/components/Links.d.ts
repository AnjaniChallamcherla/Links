/// <reference types="react" />
import * as React from 'react';
import { ILinksProps } from './ILinksProps';
import { ILinksState } from './ILinksState';
export default class QuickLinks extends React.Component<ILinksProps, ILinksState> {
    constructor(props: ILinksProps);
    componentDidMount(): Promise<void>;
    private checkLists();
    private createLinksPropsList();
    private createLinksList();
    private getLinksPropsList();
    private getLinksList();
    render(): React.ReactElement<ILinksState>;
    private _onShowNewPanel;
    private _onShowPanel;
    private _closeShowPanel();
    private _onSliderChange;
    private _onLayOutChange;
    private _next();
    private _back();
    private disTiles();
    saveLink(): Promise<void>;
    private tilesDel(e, oldTv, valTv);
}
