/// <reference types="react" />
import * as React from 'react';
import { IcompactDataProps } from './IcompactDataProps';
import { IcompactState } from './IcompactState';
export default class CompactData extends React.Component<IcompactDataProps, IcompactState> {
    constructor(props: any);
    render(): React.ReactElement<IcompactDataProps>;
    private ed(e);
    private editLink();
    private del(e);
    private delItem();
    imgChange(): void;
    private _closeDialog;
    saveLink(): Promise<void>;
}
