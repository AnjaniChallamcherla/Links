declare const styles: {
    compacDiv: string;
    compacP: string;
    compacImg: string;
    compacPDiv: string;
    compImgDiv: string;
    compact: string;
    ed: string;
    de: string;
};
export default styles;
