import { tempArray } from '../Interfaces/IUrl';
export interface IcompactDataProps {
    compactNext: (event: any) => void;
    arr1: tempArray[];
    last: string;
    btncompactNext: boolean;
    siteUrl: string;
    imgUrl: string;
    userPerm: boolean;
}
