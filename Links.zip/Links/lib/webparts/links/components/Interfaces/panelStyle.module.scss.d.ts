declare const styles: {
    panel: string;
    save: string;
    displayField: string;
    displayAddImg: string;
    buttons: string;
    attach: string;
    message: string;
    url: string;
    imgClose: string;
    container: string;
    editAttach: string;
    addLink: string;
};
export default styles;
