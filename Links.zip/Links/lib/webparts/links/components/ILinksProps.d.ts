export interface ILinksProps {
    imgUrl: string;
    siteUrl: string;
    currentUserEmail: string;
}
