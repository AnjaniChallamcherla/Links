declare const styles: {
    properties: string;
    propDiv: string;
};
export default styles;
