declare const styles: {
    listDiv: string;
    list: string;
    listEdit: string;
    listItem: string;
    listUrl: string;
    listNext: string;
    listdesc: string;
};
export default styles;
