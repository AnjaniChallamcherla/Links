/// <reference types="react" />
import * as React from 'react';
import { IlistDataProps } from './IlistDataProps';
import { IlistState } from './IlistState';
export default class ListData extends React.Component<IlistDataProps, IlistState> {
    constructor(props: any);
    render(): React.ReactElement<IlistDataProps>;
    private ed(e);
    private editLink();
    private del(e);
    private delItem();
    private _closeDialog;
    private imgChange();
    private saveLink();
}
