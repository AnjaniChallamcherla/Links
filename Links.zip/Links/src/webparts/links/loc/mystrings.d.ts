declare interface ILinksWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'LinksWebPartStrings' {
  const strings: ILinksWebPartStrings;
  export = strings;
}
