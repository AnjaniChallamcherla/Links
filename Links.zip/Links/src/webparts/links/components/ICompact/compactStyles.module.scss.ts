/* tslint:disable */
require("./compactStyles.module.css");
const styles = {
  compacDiv: 'compacDiv_f5677fdf',
  compacP: 'compacP_f5677fdf',
  compacImg: 'compacImg_f5677fdf',
  compacPDiv: 'compacPDiv_f5677fdf',
  compImgDiv: 'compImgDiv_f5677fdf',
  compact: 'compact_f5677fdf',
  ed: 'ed_f5677fdf',
  de: 'de_f5677fdf',
};

export default styles;
/* tslint:enable */