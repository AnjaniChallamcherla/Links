export interface IcompactState{
    showEditPanel:boolean;
    hideDialog:boolean;
    showPanel:boolean;
}