import * as React from 'react';
import { ITilesDataProps } from './ITilesDataProps';
import { ITilesState } from './ITilesState';
//import pnp from 'sp-pnp-js';
import { sp } from '@pnp/sp';
import { tempArray } from '../Interfaces/IUrl';

import styles from './tilesStyles.module.scss';
import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { Label } from 'office-ui-fabric-react/lib/Label';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { Image } from 'office-ui-fabric-react/lib/Image';
import panelStyle from '../Interfaces/panelStyle.module.scss';

import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';

let htmlData: any = null, htmlData1: JSX.Element = null;
let listName: string = "Links";
let selUrl: string, selDesc: string, selAttachmentFiles: string, selectedID: number, selArrID: number, selectedIDstring: string;
let existingImg: string, attachData: FileList;
let urlData: string, DescData: string;
let arr1: tempArray[] = []; let selID: number;
let ediDel: JSX.Element = <div></div>;
export default class TilesData extends React.Component<ITilesDataProps, ITilesState>{
  constructor(props) {
    super(props);
    sp.setup({
      sp: {
        baseUrl: this.props.siteUrl
      }
    });
    this.state = {
      showEditPanel: false,
      hideDialog: true
    };

  }
  public render(): React.ReactElement<ITilesDataProps> {

    const { tilesBack, tilesNext, btntilesNext, btntilesBack, userPerm } = this.props;
    const { showEditPanel, hideDialog } = this.state;
    arr1 = this.props.arr1;
    if (arr1 != null) {
      if (arr1.length > 0) {
        htmlData = arr1.map((l: tempArray) => {
          if (userPerm) {
            ediDel = <div className={styles.dis}>
              <div id={l.ID} className={styles.edi} onClick={this.ed.bind(this)}>Edit</div>
              <div id={l.ID} className={styles.del} onClick={(e) => this.del(e)}>Delete</div>
            </div>;
          }
          return (
            <div id={l.ID} className={styles.div1}>
              <div>
                <a className={styles.tilesA} data-interception="off" href={l.Url} target="_blank">
                  <img className={styles.img1} src={l.AttachmentFiles} alt="Smiley face" />
                  <div className={styles.p1}>{l.Description}</div>
                </a>
                {ediDel}
              </div>
            </div>
          );
        });
      }
    }
    htmlData1 =
      <div className={styles.roww1} >
        <div className={styles.columnn1}>
          <div className={styles.backArrow} onClick={tilesBack} id="back" hidden={btntilesBack}></div>
        </div>
        <div className={styles.column2}>
          {htmlData}
        </div>
        <div className={styles.column3}>
          <div className={styles.nextArrow} onClick={tilesNext} id="next" hidden={btntilesNext}></div>
        </div>
      </div>;
    let editPanel: JSX.Element = <div>
      <Panel
        isOpen={showEditPanel}
        type={PanelType.medium}
        headerText='Edit item'
        onDismiss={() => this.setState({ showEditPanel: false })}
        closeButtonAriaLabel='Close'
      >
        <div className={panelStyle.panel}>
          <TextField
            label="URL"
            className={panelStyle.displayField}
            placeholder="Enter a URL"
            id="urlV"
            value={selUrl}
            required={true} borderless
          />
          <Label
            id="message"
            className={panelStyle.message}>
          </Label>
          <TextField
            label="Display Text"
            className={panelStyle.displayField}
            placeholder="Enter display text"
            id="textV"
            value={selDesc}
            required={true} borderless
          />
          <Label id="message1" className={panelStyle.message}>You can't leave this blank.</Label>
          <Label className={panelStyle.displayAddImg}>Add Image:</Label>
          <div>
            <input className={panelStyle.editAttach} id="attac" type="file" accept=".jpg, .jpeg, .png" />
          </div>
          <div className={panelStyle.imgClose}>
            <button id="imgClose" onClick={this.imgChange.bind(this)}>X</button>
          </div>
          <div className={panelStyle.container}>
            <Image
              id="img"
              src={selAttachmentFiles}
              alt="Smiley face"
              width={100}
              height={100}
            />
          </div>

          <PrimaryButton
            onClick={this.editLink.bind(this)}
            text="Save"
            className={panelStyle.save}
          />
          <DefaultButton
            onClick={() => this.setState({ showEditPanel: false })}
            text="Cancel"
          />

        </div>
      </Panel>
    </div>;
    let dialog: JSX.Element = <div>
      <Dialog
        hidden={hideDialog}
        onDismiss={this._closeDialog}
        dialogContentProps={{
          type: DialogType.normal,
          title: 'Delete',
          subText: 'Are you sure you want to send the item to the site Recycle Bin?'
        }}
        modalProps={{
          titleAriaId: 'myLabelId',
          subtitleAriaId: 'mySubTextId',
          isBlocking: false,
          containerClassName: 'ms-dialogMainOverride'
        }}
      >
        <DialogFooter>
          <PrimaryButton onClick={this.delItem.bind(this)} text="Delete" />
          <DefaultButton onClick={this._closeDialog} text="Cancel" />
        </DialogFooter>
      </Dialog>
    </div>;
    let TilesD: JSX.Element =
      <div>
        {editPanel}
        {dialog}
        {htmlData1}
      </div>;
    return (
      <div>
        {TilesD}
      </div>
    );
  }
  //show edit panel with values
  private async ed(e) {
    const { oldT, valT } = this.props;
    arr1 = this.props.arr1;
    selectedID = e.target.id;
    for (let l = oldT; l < valT; l++) {
      if (arr1[l].ID == e.target.id) {
        selArrID = l;
        selUrl = arr1[l].Url;
        selDesc = arr1[l].Description;
        selAttachmentFiles = arr1[l].AttachmentFiles;
        selID = l;
      }
    }
    //console.log(selUrl+selDesc+selAttachmentFiles);
    this.setState({ showEditPanel: true });
    await Panel;
    if (!arr1[selID].Attachments) {
      this.imgChange();
    }
    (document.getElementById("attac") as HTMLInputElement).name = selAttachmentFiles;
  }
  //save edited item
  private async editLink() {
    urlData = (document.getElementById("urlV") as HTMLInputElement).value;
    DescData = (document.getElementById("textV") as HTMLInputElement).value;
    attachData = (document.getElementById("attac") as HTMLInputElement).files;
    if (urlData == "" && DescData == "") {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "You can't leave this blank.";
      document.getElementById('message1').style.display = "block";
    } else if (urlData == "") {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "You can't leave this blank.";
      document.getElementById('message1').style.display = "none";
    }
    else if (((document.getElementById("urlV") as HTMLInputElement).value.length) >= 255) {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "URL may not contain more than 255 characters";
      document.getElementById('message1').style.display = "none";
    }
    else if (DescData == "") {
      document.getElementById('message1').style.display = "block";
      document.getElementById('message1').textContent = "You can't leave this blank.";
      document.getElementById('message').style.display = "none";
    }
    else if ((urlData.substring(0, 8).toUpperCase() == "HTTPS://") || (urlData.substring(0, 7).toUpperCase() == "HTTP://")) {
      document.getElementById('message').style.display = "none";
      document.getElementById('message1').style.display = "none";
      if (urlData != arr1[selArrID].Url || DescData != arr1[selArrID].Description) {
        await sp.web.lists.getByTitle(listName).items.getById(selectedID).update({
          Url: {
            Description: DescData,
            Url: urlData
          }
        });
      }
      //console.log('image:'+document.getElementById("imgClose").style.display+'att'+arr1[selArrID].Attachments+'atts'+attachments)
      if (document.getElementById("imgClose").style.display == 'none') {
        if (arr1[selArrID].Attachments) {
          //delete existing attachment
          existingImg = arr1[selArrID].AttachmentFiles.substring(arr1[selArrID].AttachmentFiles.lastIndexOf("/") + 1, arr1[selArrID].AttachmentFiles.length);
          await sp.web.lists.getByTitle(listName).items.getById(selectedID).attachmentFiles.getByName(existingImg).delete();
          arr1[selArrID].AttachmentFiles = this.props.imgUrl;
          arr1[selArrID].Attachments = false;
        }
        if (attachData.length != 0) {
          //add new attachment
          await sp.web.lists.getByTitle(listName).items.getById(selectedID).attachmentFiles.add(attachData[0].name, attachData[0]).then(i => {
            arr1[selArrID].AttachmentFiles = "https://robertwalters.sharepoint.com" + i.data.ServerRelativeUrl;
            arr1[selArrID].Attachments = true;
          });
        }
      }
      arr1[selArrID].Description = DescData;
      arr1[selArrID].Url = urlData;
      this.setState({ showEditPanel: false });
    }
    else {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "Url must start with https://";
      document.getElementById('message1').style.display = "none";
    }
  }
  private del(e) {
    selectedID = e.target.id;
    selectedIDstring = selectedID.toString();
    this.setState({ hideDialog: false });
  }
  private async delItem() {
    const { tilesDel, oldT, valT } = this.props;
    tilesDel(selectedIDstring, oldT, valT);
    this.setState({ hideDialog: true });
  }
  //hide image on edit link panel
  private imgChange() {
    document.getElementById("imgClose").style.display = 'none';
    document.getElementById("img").style.display = "none";
    document.getElementById("attac").style.display = 'inline';
  }
  //close delete dialog box
  private _closeDialog = (e): void => {
    this.setState({ hideDialog: true });
  }
}