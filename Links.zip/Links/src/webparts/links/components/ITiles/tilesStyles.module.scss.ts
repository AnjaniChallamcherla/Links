/* tslint:disable */
require("./tilesStyles.module.css");
const styles = {
  div1: 'div1_223effe8',
  img1: 'img1_223effe8',
  p1: 'p1_223effe8',
  tilesA: 'tilesA_223effe8',
  dis: 'dis_223effe8',
  edi: 'edi_223effe8',
  del: 'del_223effe8',
  roww1: 'roww1_223effe8',
  columnn1: 'columnn1_223effe8',
  column3: 'column3_223effe8',
  column2: 'column2_223effe8',
  nextArrow: 'nextArrow_223effe8',
  backArrow: 'backArrow_223effe8',
};

export default styles;
/* tslint:enable */