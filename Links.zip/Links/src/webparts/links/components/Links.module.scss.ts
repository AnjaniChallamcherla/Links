/* tslint:disable */
require("./Links.module.css");
const styles = {
  properties: 'properties_c11a2e5b',
  propDiv: 'propDiv_c11a2e5b',
};

export default styles;
/* tslint:enable */