/* tslint:disable */
require("./panelStyle.module.css");
const styles = {
  panel: 'panel_82b3c995',
  save: 'save_82b3c995',
  displayField: 'displayField_82b3c995',
  displayAddImg: 'displayAddImg_82b3c995',
  buttons: 'buttons_82b3c995',
  attach: 'attach_82b3c995',
  message: 'message_82b3c995',
  url: 'url_82b3c995',
  imgClose: 'imgClose_82b3c995',
  container: 'container_82b3c995',
  editAttach: 'editAttach_82b3c995',
  addLink: 'addLink_82b3c995',
};

export default styles;
/* tslint:enable */