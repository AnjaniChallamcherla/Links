export interface IUrls{
    ID:string;
    Url:ILinks;
    AttachmentFiles:attach;
    Attachments:boolean;
}
export interface ILinks{
    Url:string;
    Description:string;
}
export interface attach{
    ServerRelativeUrl:string;
}
export interface tempArray{
    ID:string;
    Url:string;
    Description:string;
    AttachmentFiles:string;
    Attachments:boolean;
}
export interface IaLists{
    Title: string;
}
export interface ILinksPropsList{
    Title:string;
    ItemCount:number;
}