/* tslint:disable */
require("./listStyles.module.css");
const styles = {
  listDiv: 'listDiv_3b4969ce',
  list: 'list_3b4969ce',
  listEdit: 'listEdit_3b4969ce',
  listItem: 'listItem_3b4969ce',
  listUrl: 'listUrl_3b4969ce',
  listNext: 'listNext_3b4969ce',
  listdesc: 'listdesc_3b4969ce',
};

export default styles;
/* tslint:enable */