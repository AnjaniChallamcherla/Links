import * as React from 'react';
import { IlistDataProps } from './IlistDataProps';
import { IlistState } from './IlistState';
//import pnp from 'sp-pnp-js';
import { sp } from '@pnp/sp';
import { tempArray } from '../Interfaces/IUrl';
import styles from './listStyles.module.scss';
import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { Label } from 'office-ui-fabric-react/lib/Label';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { Image } from 'office-ui-fabric-react/lib/Image';
import panelStyle from '../Interfaces/panelStyle.module.scss';
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
let listName: string = "Links";
let htmlData: any;
let selUrl: string, selDesc: string, selAttachmentFiles: string, selectedID: number, selArrID: number, selectedIDstring: string;
let existingImg: string, attachData: FileList;
let urlData: string, DescData: string, textData: string, addedID: number, addedImage: string;
let addItem: tempArray, arr1: tempArray[] = [], selID: number;
let editDel: JSX.Element = <div></div>, addLink: JSX.Element;
export default class ListData extends React.Component<IlistDataProps, IlistState>{
  constructor(props) {
    super(props);
    sp.setup({
      sp: {
        baseUrl: this.props.siteUrl
      }
    });
    this.state = {
      showEditPanel: false,
      hideDialog: true,
      showPanel: false
    };
  }
  public render(): React.ReactElement<IlistDataProps> {

    const { listNext, btnlistNext, userPerm } = this.props;
    const { showEditPanel, hideDialog, showPanel } = this.state;
    arr1 = this.props.arr1;
    if (arr1 != null) {
      if (arr1.length > 0) {
        htmlData = arr1.map((li: tempArray) => {
          if (userPerm) {
            editDel = <div className={styles.list}>
              <text className={styles.listEdit} id={li.ID} onClick={this.ed.bind(this)}>Edit</text>
              <text id={li.ID} onClick={(e) => this.del(e)}>Delete</text>
            </div>;
          }
          return (
            <div>
              <div>
                <div className={styles.listDiv}>
                  <a href={li.Url} data-interception="off" target="_blank" className={styles.listUrl} >
                    <div className={styles.listdesc}>{li.Description}</div>
                  </a>
                  {editDel}
                </div>
              </div>
            </div>
          );
        });
      }
    }
    let newPanel: JSX.Element = <div>
      <Panel
        isOpen={showPanel}
        type={PanelType.medium}
        headerText='New item'
        onDismiss={() => this.setState({ showPanel: false })}
        closeButtonAriaLabel='Close'
      >
        <div className={panelStyle.panel}>
          <TextField
            label="URL"
            className={panelStyle.displayField}
            placeholder="Enter a Url"
            id="urlV"
            required={true} borderless
          />
          <Label
            id="message"
            className={panelStyle.message}>
          </Label>
          <TextField
            label="Display Text"
            className={panelStyle.displayField}
            placeholder="Enter display text"
            id="textV"
            required={true} borderless
          />
          <Label id="message1" className={panelStyle.message}>You can't leave this blank.</Label>
          <Label className={panelStyle.displayAddImg}>Add Image:</Label>
          <input className={panelStyle.attach} id="attac" type="file" accept=".jpg, .jpeg, .png" />
          <div className={panelStyle.buttons}>
            <PrimaryButton
              onClick={this.saveLink.bind(this)}
              text="Save"
              className={panelStyle.save}
            />
            <DefaultButton
              onClick={() => this.setState({ showPanel: false })}
              text="Cancel"
            />
          </div>
        </div>
      </Panel>
    </div>;
    let editPanel: JSX.Element = <div>
      <Panel
        isOpen={showEditPanel}
        type={PanelType.medium}
        headerText='Edit item'
        onDismiss={() => this.setState({ showEditPanel: false })}
        closeButtonAriaLabel='Close'
      >
        <div className={panelStyle.panel}>
          <TextField
            label="URL"
            className={panelStyle.displayField}
            placeholder="Enter a URL"
            id="urlV"
            value={selUrl}
            required={true} borderless
          />
          <Label
            id="message"
            className={panelStyle.message}>
          </Label>
          <TextField
            label="Display Text"
            className={panelStyle.displayField}
            placeholder="Enter display text"
            id="textV"
            value={selDesc}
            required={true} borderless
          />
          <Label id="message1" className={panelStyle.message}>You can't leave this blank.</Label>
          <Label className={panelStyle.displayAddImg}>Add Image:</Label>
          <div>
            <input className={panelStyle.editAttach} id="attac" type="file" accept=".jpg, .jpeg, .png" />
          </div>
          <div className={panelStyle.container}>
            <button id="imgClose" className={panelStyle.imgClose} onClick={this.imgChange.bind(this)}>X</button>
            <Image
              id="img"
              src={selAttachmentFiles}
              alt="Smiley face"
              width={100}
              height={100}
            />
          </div>

          <PrimaryButton
            onClick={this.editLink.bind(this)}
            text="Save"
            className={panelStyle.save}
          />
          <DefaultButton
            onClick={() => this.setState({ showEditPanel: false })}
            text="Cancel"
          />

        </div>
      </Panel>
    </div>;
    let dialog: JSX.Element = <div>
      <Dialog
        hidden={hideDialog}
        onDismiss={this._closeDialog}
        dialogContentProps={{
          type: DialogType.normal,
          title: 'Delete',
          subText: 'Are you sure you want to send the item to the site Recycle Bin?'
        }}
        modalProps={{
          titleAriaId: 'myLabelId',
          subtitleAriaId: 'mySubTextId',
          isBlocking: false,
          containerClassName: 'ms-dialogMainOverride'
        }}
      >
        <DialogFooter>
          <PrimaryButton onClick={this.delItem.bind(this)} text="Delete" />
          <DefaultButton onClick={this._closeDialog} text="Cancel" />
        </DialogFooter>
      </Dialog>
    </div>;
    if (this.props.userPerm) {
      addLink = <div>
        <PrimaryButton
          onClick={() => this.setState({ showPanel: true })}
          text="Add Link"
          className={panelStyle.addLink}
        />
      </div>;
    }
    let listRes: JSX.Element = <div>
      {addLink}
      {newPanel}
      {editPanel}
      {dialog}
      {htmlData}
      <div>
        <PrimaryButton
          id="compacNext"
          onClick={listNext}
          text="More Links"
          disabled={btnlistNext}
        />
      </div>
    </div>;
    return (
      <div>
        {listRes}
      </div>
    );
  }
  //show edit panel with values
  private async ed(e) {
    arr1 = this.props.arr1;
    selectedID = e.target.id;
    if (arr1 != null) {
      if (arr1.length > 0) {
        for (let l = 0; l < arr1.length; l++) {
          if (arr1[l].ID == e.target.id) {
            selArrID = l;
            selUrl = arr1[l].Url;
            selDesc = arr1[l].Description;
            selAttachmentFiles = arr1[l].AttachmentFiles;
            selID = l;
          }
        }
      }
    }
    this.setState({ showEditPanel: true });
    await Panel;
    if (!arr1[selID].Attachments) {
      this.imgChange();
    }
    (document.getElementById("attac") as HTMLInputElement).name = selAttachmentFiles;
  }
  //save edited item
  private async editLink() {
    urlData = (document.getElementById("urlV") as HTMLInputElement).value;
    DescData = (document.getElementById("textV") as HTMLInputElement).value;
    attachData = (document.getElementById("attac") as HTMLInputElement).files;
    if (urlData == "" && DescData == "") {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "You can't leave this blank.";
      document.getElementById('message1').style.display = "block";
    } else if (urlData == "") {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "You can't leave this blank.";
      document.getElementById('message1').style.display = "none";
    }
    else if (((document.getElementById("urlV") as HTMLInputElement).value.length) >= 255) {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "URL may not contain more than 255 characters";
      document.getElementById('message1').style.display = "none";
    }
    else if (DescData == "") {
      document.getElementById('message1').style.display = "block";
      document.getElementById('message').style.display = "none";
    }
    else if ((urlData.substring(0, 8).toUpperCase() == "HTTPS://") || (urlData.substring(0, 7).toUpperCase() == "HTTP://")) {
      document.getElementById('message').style.display = "none";
      document.getElementById('message1').style.display = "none";
      if (urlData != arr1[selArrID].Url || DescData != arr1[selArrID].Description) {
        await sp.web.lists.getByTitle(listName).items.getById(selectedID).update({
          Url: {
            Description: DescData,
            Url: urlData
          }
        });
      }
      if (document.getElementById("imgClose").style.display == 'none') {
        if (arr1[selArrID].Attachments) {
          //delete existing attachment
          existingImg = arr1[selArrID].AttachmentFiles.substring(arr1[selArrID].AttachmentFiles.lastIndexOf("/") + 1, arr1[selArrID].AttachmentFiles.length);
          await sp.web.lists.getByTitle(listName).items.getById(selectedID).attachmentFiles.getByName(existingImg).delete();
          arr1[selArrID].AttachmentFiles = this.props.imgUrl;
          arr1[selArrID].Attachments = false;
        }
        if (attachData.length != 0) {
          //add new attachment
          await sp.web.lists.getByTitle(listName).items.getById(selectedID).attachmentFiles.add(attachData[0].name, attachData[0]).then(i => {
            arr1[selArrID].AttachmentFiles = "https://robertwalters.sharepoint.com" + i.data.ServerRelativeUrl;
            arr1[selArrID].Attachments = true;
          });
        }
      }
      arr1[selArrID].Description = DescData;
      arr1[selArrID].Url = urlData;
      this.setState({ showEditPanel: false });
    }
    else {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "Url must start with https://";
      document.getElementById('message1').style.display = "none";
    }
  }
  //open delete dialog
  private del(e) {
    selectedID = e.target.id;
    selectedIDstring = selectedID.toString();
    this.setState({ hideDialog: false });
  }
  //delete link
  private async delItem() {
    arr1 = this.props.arr1;
    for (let l = 0; l < arr1.length; l++) {
      if (arr1[l].ID == selectedID.toString()) {
        selArrID = l;
      }
    }
    await sp.web.lists.getByTitle(listName).items.getById(selectedID).delete().then(() => {
      for (let k = 0; k < arr1.length; k++) {
        if (arr1[k].ID == selectedIDstring) {
          arr1.splice(arr1.indexOf(arr1[k]), 1);
        }
      }
    });
    this.setState({ hideDialog: true });
  }
  //close delete dialog box
  private _closeDialog = (e): void => {
    this.setState({ hideDialog: true });
  }
  //hide image on edit link panel
  private imgChange() {
    document.getElementById("imgClose").style.display = 'none';
    document.getElementById("img").style.display = "none";
    document.getElementById("attac").style.display = 'inline';
  }
  //add item
  private async saveLink() {
    arr1 = this.props.arr1;
    urlData = (document.getElementById("urlV") as HTMLInputElement).value;
    textData = (document.getElementById("textV") as HTMLInputElement).value;
    //check if attachment exists
    attachData = (document.getElementById("attac") as HTMLInputElement).files;
    if (urlData == "" && textData == "") {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "You can't leave this blank.";
      document.getElementById('message1').style.display = "block";
    }
    else if (urlData == "") {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "You can't leave this blank.";
      document.getElementById('message1').style.display = "none";
    }
    else if (((document.getElementById("urlV") as HTMLInputElement).value.length) >= 255) {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "URL may not contain more than 255 characters";
      document.getElementById('message1').style.display = "none";
    }
    else if (textData == "") {
      document.getElementById('message1').style.display = "block";
      document.getElementById('message').style.display = "none";
    }
    else if ((urlData.substring(0, 8).toUpperCase() == "HTTPS://") || (urlData.substring(0, 7).toUpperCase() == "HTTP://")) {
      document.getElementById('message').style.display = "none";
      document.getElementById('message1').style.display = "none";

      await sp.web.lists.getByTitle(listName).items.add({
        //data
        Url: {
          Description: textData,
          Url: urlData
        }
      }).then(i => addedID = i.data.ID);
      //check attachment exists
      if (attachData.length != 0) {
        //add attachments
        await sp.web.lists.getByTitle(listName).items.getById(addedID).attachmentFiles.add(attachData[0].name, attachData[0]).then(
          i => {
            addedImage = "https://robertwalters.sharepoint.com" + i.data.ServerRelativeUrl;
          });
      }

      this.setState({ showPanel: false });
      if (attachData.length == 0) {
        addItem =
          {
            Url: urlData,
            Description: textData,
            AttachmentFiles: this.props.imgUrl,
            Attachments: false,
            ID: addedID.toString()
          };
      }
      else {
        addItem =
          {
            Url: urlData,
            Description: textData,
            AttachmentFiles: addedImage,
            Attachments: true,
            ID: addedID.toString()
          };
      }
      arr1.unshift(addItem);
    }
    else {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "Url must start with https://";
      document.getElementById('message1').style.display = "none";
    }
    this.setState({ showEditPanel: false });
  }

}
