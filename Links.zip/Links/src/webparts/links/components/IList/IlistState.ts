export interface IlistState{
    showEditPanel:boolean;
    hideDialog:boolean;
    showPanel:boolean;
}