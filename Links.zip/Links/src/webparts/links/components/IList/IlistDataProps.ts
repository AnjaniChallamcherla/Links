import {tempArray} from '../Interfaces/IUrl';
export interface IlistDataProps{
        listNext : (event:any) => void;
        arr1:tempArray[];
        btnlistNext:boolean;
        siteUrl:string;
        imgUrl:string;
        userPerm:boolean;
}