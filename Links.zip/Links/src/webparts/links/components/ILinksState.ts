import {tempArray} from './Interfaces/IUrl';
export interface ILinksState{
    showPanel:boolean;
    slider:number;
    lay:string;
    Data:JSX.Element;
    compactArr:tempArray[];
    //list states
    listArr:tempArray[];
    tilesArr:tempArray[];
    showNewPanel:boolean;
    sliderDis:boolean;
    
}