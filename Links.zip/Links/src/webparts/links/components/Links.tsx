//.tsx with e
import * as React from 'react';
import styles from './Links.module.scss';
//import styles from './Links.module.scss';
import { ILinksProps } from './ILinksProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { ILinksState } from './ILinksState';

import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';
import { Label } from 'office-ui-fabric-react/lib/Label';
import { TextField } from 'office-ui-fabric-react/lib/TextField';

import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';

import { Slider } from 'office-ui-fabric-react/lib/Slider';
import { ChoiceGroup } from 'office-ui-fabric-react/lib/ChoiceGroup';
import ListData from '../components/IList/listData';
import CompactData from '../components/ICompact/IcompactData';
import TilesData from '../components/ITiles/ITilesData';
import { IUrls, tempArray, ILinksPropsList, IaLists } from './Interfaces/IUrl';
import panelStyle from './Interfaces/panelStyle.module.scss';
//import pnp,{UrlFieldFormatType} from 'sp-pnp-js';
import { sp, UrlFieldFormatType, PermissionKind } from '@pnp/sp';
let sliderValue: number = 0, layout: string = '';
//new list
let listName: string = "Links", linksListName: string = "Links Properties";
let urlField: string = "Url", getItems: number = 4;
let linksListExist: boolean = false, linksPropsListExist: boolean = false;
//tiles data
let oldT: number = 0, valT: number = 4;
let btntilesNext: boolean, btntilesBack: boolean, tilesTemp: number = 0;
let arr2: tempArray[] = [], disTilesA: tempArray[] = [], tilesNew: boolean = false;
//let tempLast: string = 'yes';
let newPanel: JSX.Element;

//compact data
let attachData: FileList;
let arr: any, newItem: tempArray, nextItem: tempArray, arr1: tempArray[] = [], next: Function, last: string = 'no';
let valC: number = 0;
let btncompactNext: boolean;

//list data
let valL: number = 0;
let btnlistNext: boolean, addItem: tempArray;
let urlData: string, textData: string, addedID: number, addedImage: string;
//user Permission
let userPerm: boolean, tilesAddLink: JSX.Element = null, propBut: JSX.Element = null;


export default class QuickLinks extends React.Component<ILinksProps, ILinksState> {
  public constructor(props: ILinksProps) {

    super(props);
    sp.setup({
      sp: {
        baseUrl: this.props.siteUrl
      }
    });

    this.state = {
      showPanel: false,
      slider: 0,
      lay: '',
      Data: <div>Loading</div>,
      compactArr: [],
      listArr: [],
      tilesArr: [],
      showNewPanel: false,
      sliderDis: false
    };
    this.getLinksList = this.getLinksList.bind(this);

  }
  public async componentDidMount() {
    this.setState({ Data: <div>Loading...Please wait</div> });
    console.log("User Name: " + this.props.currentUserEmail);
    await sp.web.userHasPermissions("i:0#.f|membership|" + this.props.currentUserEmail, PermissionKind.ManageLists).then(perms => {
      userPerm = perms;
      console.log('userMail ' + this.props.currentUserEmail + ' UserPerm ' + userPerm);
    }).catch(e => console.log(e.message));
    await this.checkLists();
  }
  private async checkLists() {
    await sp.web.lists.select("Title").get().then((aLists: IaLists[]) => {
      if (aLists != null) {
        if (aLists.length > 0) {
          aLists.map((aList: IaLists) => {
            //check if links list exist
            if (aList.Title == listName) {
              linksListExist = true;
            }
            //check if links Properties list exist
            if (aList.Title == linksListName) {
              linksPropsListExist = true;
            }
          });
          console.log("LinksList: " + linksListExist + " LinksPropsList: " + linksPropsListExist);
          if (linksListExist && linksPropsListExist) {
            //Go and get the Links Properties first...
            (async () => {
              await this.getLinksPropsList();
            })();
          } else if (!linksPropsListExist && !linksListExist) {
            //Go and create the two list first
            (async () => {
              //Should batch these together but for now just run sequentially 
              await this.createLinksPropsList();
              await this.createLinksList();
            })();
          }
          else if (linksPropsListExist && !linksListExist) {
            (async () => {
              await this.createLinksList();
              await this.getLinksPropsList();
            })();
          }
          else if (!linksPropsListExist && linksListExist) {
            (async () => {
              await this.createLinksPropsList();
              await this.getLinksList();
            })();
          }
        }
      }
    }).catch(e => console.log(e.message));   
  }
  private async createLinksPropsList() {
    await sp.web.lists.add(linksListName, linksListName, 100, false).then(async (r) => {
      if (r.data.Created) {
        await sp.web.lists.getByTitle(linksListName).fields.addNumber('ItemCount').then(async () => {
          await sp.web.lists.getByTitle(linksListName).defaultView.fields.add('ItemCount');
          await sp.web.lists.getByTitle(linksListName).items.add({
            Title: 'Tiles',
            ItemCount: 4
          });
        }).catch(er => console.log(er.message));
        sliderValue = 4;
        layout = "Tiles";
      }
      console.log("Created LinksPropsList");
    }).catch(e => console.log(e.message));
  }
  private async createLinksList() {
    await sp.web.lists.add(listName, listName, 100, false).then(async (i) => {
      if (i.data.Created) {
        await sp.web.lists.getByTitle(listName).fields.getByTitle("Title").update({ Required: false }).then(async () => {
          await sp.web.lists.getByTitle(listName).fields.addUrl(urlField, UrlFieldFormatType.Hyperlink).then(async () => {
            await sp.web.lists.getByTitle(listName).defaultView.fields.add(urlField).then(async () => {
              await sp.web.lists.getByTitle(listName).defaultView.fields.add("Attachments").then(async () => {
                console.log("Created LinksList");
                await this.getLinksList();
              }).catch(e => console.log(e.message));
            }).catch(e => console.log(e.message));
          }).catch(e => console.log(e.message));
        }).catch(e => console.log(e.message));
      }
    }).catch(e => console.log(e.message));
  }
  private async getLinksPropsList() {
    await sp.web.lists.getByTitle(linksListName).items.select("Title", "ItemCount").getById(1).get().then(async (u: ILinksPropsList) => {
      if (u != null) {
        sliderValue = u.ItemCount;
        layout = u.Title;
        console.log("LinksProps:" + sliderValue + " " + layout+" UserPerm: "+this.props.currentUserEmail+" "+userPerm);
        await this.getLinksList();
      }
    }).catch(e => console.log(e.message));
  }
  private async getLinksList() {
    await this.setState({
      slider: sliderValue,
      lay: layout
    });
    await sp.web.lists.getByTitle(listName).items.select("ID", "Title", urlField, "AttachmentFiles/ServerRelativeUrl", "Attachments").expand("AttachmentFiles").top(getItems).orderBy('Id', false).getPaged().then(p => {
      console.log(p.results);
    });
    
  /*
    if (layout == "Tiles") { this.setState({ sliderDis: true }); } else { this.setState({ sliderDis: false }); }
    //get array data
    getItems = layout == "Tiles" ? 4 : sliderValue;
    await sp.web.lists.getByTitle(listName).items.select("ID", "Title", urlField, "AttachmentFiles/ServerRelativeUrl", "Attachments").expand("AttachmentFiles").top(getItems).orderBy('Id', false).getPaged().then(p => {
      arr = p;
      arr.results.map((i: IUrls) => {
        if (i.Attachments) {
          newItem = {
            ID: i.ID,
            Url: i.Url.Url,
            Description: i.Url.Description,
            AttachmentFiles: "https://robertwalters.sharepoint.com" + i.AttachmentFiles[0].ServerRelativeUrl,
            Attachments: i.Attachments
          };
        }
        else {
          newItem = {
            ID: i.ID,
            Url: i.Url.Url,
            Description: i.Url.Description,
            AttachmentFiles: this.props.imgUrl,
            Attachments: i.Attachments
          };
        }
        arr1.push(newItem);
      });
      //get next data   
      next = async () => {
        if (arr.hasNext) {
          await arr.getNext().then(p2 => {
            arr = p2;
            arr.results.map((j: IUrls) => {
              if (j.Attachments) {
                nextItem = {
                  ID: j.ID,
                  Url: j.Url.Url,
                  Description: j.Url.Description,
                  AttachmentFiles: "https://robertwalters.sharepoint.com" + j.AttachmentFiles[0].ServerRelativeUrl,
                  Attachments: j.Attachments
                };
              }
              else {
                nextItem = {
                  ID: j.ID,
                  Url: j.Url.Url,
                  Description: j.Url.Description,
                  AttachmentFiles: this.props.imgUrl,
                  Attachments: j.Attachments
                };
              }
              arr1.push(nextItem);
            });
          }).catch(e => console.log(e.message));
        }
        if (arr.hasNext) { }
        else { last = 'yes'; }
      };
      if (arr.hasNext) { }
      else { last = 'yes'; }
    }).catch(e => console.log(e.message));
    
    if (layout == "Tiles") {
      tilesTemp = tilesTemp != 0 ? 0 : tilesTemp;
      oldT = 0;
      valT = last == 'yes' && arr1.length <= valT ? arr1.length : arr1.length;
      this.setState({ tilesArr: [] });
      disTilesA = [];
      //console.log('layoutT' + layout + 'oldT' + oldT + 'valT' + valT + 'arr1.le' + arr1.length + 'tilesTemp' + tilesTemp + 'last' + last);
      this.disTiles();
    }
    else if (layout == "Compact") {
      valC = last == 'yes' && arr1.length <= valC ? arr1.length : arr1.length;
      btncompactNext = last == 'yes' ? true : false;
      this.setState({ Data: <CompactData userPerm={userPerm} imgUrl={this.props.imgUrl} siteUrl={this.props.siteUrl} arr1={arr1} compactNext={this._next.bind(this)} last={last} btncompactNext={btncompactNext} /> });
      this.setState({ compactArr: arr1 });
      //console.log('layoutC:'+layout+'valc'+valC+'arr1.le'+arr1.length+'this.state.compactArr'+this.state.compactArr.length+'slid'+sliderValue+'btncompnext'+btncompactNext+'last'+last);
    }
    else if (layout == "List") {
      valL = last == 'yes' && arr1.length <= valL ? arr1.length : arr1.length;
      btnlistNext = last == 'yes' ? true : false;
      this.setState({ Data: <ListData userPerm={userPerm} imgUrl={this.props.imgUrl} siteUrl={this.props.siteUrl} arr1={arr1} listNext={this._next.bind(this)} btnlistNext={btnlistNext} /> });
      this.setState({ listArr: arr1 });
      //console.log('layoutL'+layout+'valL'+valL+'arr1.le'+arr1.length+'this.state.listArrLen'+this.state.listArr.length+'last'+last+'btnlistNext'+btnlistNext+'slidVal'+sliderValue);
    }
*/    
    arr1 = [];
  }
  public render(): React.ReactElement<ILinksState> {
    let proPanel: JSX.Element = <Panel
      isOpen={this.state.showPanel}
      type={PanelType.smallFixedFar}
      headerText='Properties'
      onDismiss={this._closeShowPanel.bind(this)}
      closeButtonAriaLabel='Close'
    >
      <Slider
        label="Number of Items:"
        min={1}
        max={10}
        step={1}
        showValue={true}
        onChange={(value: number) => this._onSliderChange(value)}
        value={this.state.slider}
        disabled={this.state.sliderDis}
      />
      <ChoiceGroup
        label="Layout options"
        onChange={this._onLayOutChange}
        selectedKey={this.state.lay}
        options={[
          {
            key: 'Compact',
            iconProps: { iconName: 'Code' },
            text: 'Compact'
          },
          {
            key: 'Tiles',
            iconProps: { iconName: 'Tiles' },
            text: 'Tiles'
          },
          {
            key: 'List',
            iconProps: { iconName: 'List' },
            text: 'List'
          }
        ]}
      />
    </Panel>;
    newPanel = <div>
      <Panel
        isOpen={this.state.showNewPanel}
        type={PanelType.medium}
        headerText='New item'
        onDismiss={() => this.setState({ showNewPanel: false })}
        closeButtonAriaLabel='Close'
      >
        <div className={panelStyle.panel}>
          <TextField
            label="URL"
            className={panelStyle.displayField}
            placeholder="Enter a Url"
            id="urlV"
            required={true} borderless
          />
          <Label
            id="message"
            className={panelStyle.message}>
          </Label>
          <TextField
            label="Display Text"
            className={panelStyle.displayField}
            placeholder="Enter display text"
            id="textV"
            required={true} borderless
          />
          <Label id="message1" className={panelStyle.message}>You can't leave this blank.</Label>
          <Label className={panelStyle.displayAddImg}>Add Image:</Label>
          <input className={panelStyle.attach} id="attac" type="file" accept=".jpg, .jpeg, .png" />
          <div className={panelStyle.buttons}>
            <PrimaryButton
              onClick={this.saveLink.bind(this)}
              text="Save"
              className={panelStyle.save}
            />
            <DefaultButton
              onClick={() => this.setState({ showNewPanel: false })}
              text="Cancel"
            />
          </div>
        </div>
      </Panel>
    </div>;
    if (userPerm) {
      propBut = <DefaultButton id="btnProperties" className={styles.properties} text="Properties" onClick={this._onShowPanel} />;
    }
    return (
      <div>
        <div className={styles.propDiv}>
          {propBut}
          {newPanel}
          {proPanel}
          {this.state.Data}
        </div>
      </div>
    );
  }
  private _onShowNewPanel = (): void => {
    this.setState({ showNewPanel: true });
  }
  private _onShowPanel = (): void => {
    this.setState({ showPanel: true });
  }
  private async _closeShowPanel() {
    await sp.web.lists.getByTitle(linksListName).items.getById(1).update({
      Title: layout,
      ItemCount: sliderValue
    });
    this.setState({ showPanel: false });
  }
  private _onSliderChange = (value): void => {
    last = 'no';
    sliderValue = value;
    this.setState({ slider: value });
    this.getLinksList();
  }
  private _onLayOutChange = (ev: React.FormEvent<HTMLInputElement>, option: any): void => {
    last = 'no';
    layout = option.key;
    if (layout == "Tiles") { this.setState({ sliderDis: true }); } else { this.setState({ sliderDis: false }); }
    this.setState({ lay: layout });
    this.getLinksList();
  }

  private async _next() {
    if (layout == "Compact") {
      if (this.state.compactArr != null) {
        if (this.state.compactArr.length > 0) {
          this.state.compactArr.map(i => arr1.push(i));
        }
      }
      await next();
      valC = valC + sliderValue;
      last == 'yes' && arr1.length <= valC ? valC = arr1.length : valC = sliderValue,
        this.setState({ compactArr: arr1 });
      btncompactNext = last == 'yes' ? true : false;
      this.setState({ Data: <CompactData userPerm={userPerm} imgUrl={this.props.imgUrl} siteUrl={this.props.siteUrl} arr1={this.state.compactArr} compactNext={this._next.bind(this)} last={last} btncompactNext={btncompactNext} /> });
      //console.log('compactNext'+'arr1.le'+arr1.length+'this.sta.compaArr.le'+this.state.compactArr.length+'btncompacNe'+btncompactNext+'last'+last+'valc'+valC);
      arr1 = [];
    }
    else if (layout == "List") {
      if (this.state.listArr != null) {
        if (this.state.listArr.length > 0) {
          this.state.listArr.map(i => arr1.push(i));
        }
      }
      await next();
      valL = valL + sliderValue;
      valL = last == 'yes' && arr1.length <= valL ? arr1.length : sliderValue,
        this.setState({ listArr: arr1 });
      btnlistNext = last == 'yes' ? true : false;
      this.setState({ Data: <ListData userPerm={userPerm} imgUrl={this.props.imgUrl} siteUrl={this.props.siteUrl} arr1={this.state.listArr} listNext={this._next.bind(this)} btnlistNext={btnlistNext} /> });
      //console.log('listNext'+'arr1.le'+arr1.length+'this.sta.listArr.le'+this.state.listArr.length+'btnlistcNe'+btnlistNext+'last'+last+'vall'+valL);

      arr1 = [];
    }
    else if (layout == "Tiles") {
      disTilesA = [];
      if (this.state.tilesArr != null) {
        if (this.state.tilesArr.length > 0) {
          this.state.tilesArr.map(i => arr1.push(i));
        }
      }
      if (tilesTemp == 0) {
        await next();
        this.setState({ tilesArr: arr1 });
      }
      else {
        --tilesTemp;
      }
      oldT = valT;
      valT = valT + 4;
      valT = last == 'yes' && arr1.length <= valT ? arr1.length : valT,
        btntilesBack = oldT <= 0 ? true : false;
      btntilesNext = last == 'yes' && valT == this.state.tilesArr.length ? true : false;
      // console.log('next'+'tempLast'+tempLast+'arr1.le'+arr1.length+'tilesArrLe'+this.state.tilesArr.length+'nextB'+btntilesNext+'backB'+btntilesBack+'tilesTemp'+tilesTemp+'last'+last+'oldT'+oldT+'valT'+valT+'arr2L'+arr2.length);
      for (let m = oldT; m < valT; m++) { arr2[m] = this.state.tilesArr[m]; }
      //console.log('up' + userPerm);
      if (userPerm) {
        tilesAddLink = <div>
          <PrimaryButton
            onClick={this._onShowNewPanel}
            text="Add Link"
            className={panelStyle.addLink}
          /></div>;
      }
      this.setState({
        Data:
          <div>
            {tilesAddLink}
            <TilesData userPerm={userPerm} imgUrl={this.props.imgUrl} siteUrl={this.props.siteUrl} tilesDel={this.tilesDel.bind(this)} oldT={oldT} valT={valT} arr1={arr2} tilesBack={this._back.bind(this)} tilesNext={this._next.bind(this)} btntilesNext={btntilesNext} btntilesBack={btntilesBack} />
          </div>
      });//

      arr1 = [];
      arr2 = [];
    }
  }
  private async _back() {
    //console.log('bbb');
    ++tilesTemp;
    valT = oldT;
    oldT = oldT - 4;
    if (oldT <= 0) { btntilesBack = true; }
    if (last == 'yes' && valT == this.state.tilesArr.length) { btntilesNext = true; }
    else { btntilesNext = false; }
    // console.log('back'+'lastt'+last+'oldT'+oldT+'valT'+valT+'this.state.tilesArr.len'+this.state.tilesArr.length+'tilesTemp'+tilesTemp+'back'+btntilesBack+'next'+btntilesNext);
    for (let m = oldT; m < valT; m++) { arr2[m] = this.state.tilesArr[m]; }
    if (userPerm) {
      tilesAddLink = <div>
        <PrimaryButton
          onClick={this._onShowNewPanel}
          text="Add Link"
          className={panelStyle.addLink}
        /></div>;
    }
    this.setState({
      Data:
        <div>
          {tilesAddLink}
          <TilesData userPerm={userPerm} imgUrl={this.props.imgUrl} siteUrl={this.props.siteUrl} tilesDel={this.tilesDel.bind(this)} oldT={oldT} valT={valT} arr1={arr2} tilesBack={this._back.bind(this)} tilesNext={this._next.bind(this)} btntilesNext={btntilesNext} btntilesBack={btntilesBack} />
        </div>
    });//

    arr2 = [];
  }
  private disTiles() {
    btntilesNext = last == 'yes' && this.state.tilesArr.length <= 4 ? true : false;
    //console.log('testTiles'+'oldT'+oldT+'valT'+valT+'tilesNew'+tilesNew+'btntilesNext'+btntilesNext+'tempLast'+tempLast+'last'+last);

    for (let k = oldT; k < valT; k++) {
      if (tilesNew == true) {
        disTilesA[k] = this.state.tilesArr[k];
      }
      else {
        disTilesA[k] = arr1[k];
      }
    }
    if (userPerm) {
      tilesAddLink = <div>
        <PrimaryButton
          onClick={this._onShowNewPanel}
          text="Add Link"
          className={panelStyle.addLink}
        /></div>;
    }
    this.setState({
      Data:
        <div>
          {tilesAddLink}
          <TilesData userPerm={userPerm} imgUrl={this.props.imgUrl} siteUrl={this.props.siteUrl} tilesDel={this.tilesDel.bind(this)} oldT={oldT} valT={valT} arr1={disTilesA} tilesBack={this._back.bind(this)} tilesNext={this._next.bind(this)} btntilesNext={btntilesNext} btntilesBack={true} />
        </div>
    });// 

    if (tilesNew == false) {
      this.setState({ tilesArr: arr1 });
    }
    tilesNew = false;
    disTilesA = [];
    arr1 = [];
  }

  //add item
  public async saveLink() {
    urlData = (document.getElementById("urlV") as HTMLInputElement).value;
    textData = (document.getElementById("textV") as HTMLInputElement).value;
    //check if attachment exists
    attachData = (document.getElementById("attac") as HTMLInputElement).files;
    if (urlData == "" && textData == "") {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "You can't leave this blank.";
      document.getElementById('message1').style.display = "block";
    }
    else if (urlData == "") {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "You can't leave this blank.";
      document.getElementById('message1').style.display = "none";
    }
    else if (((document.getElementById("urlV") as HTMLInputElement).value.length) >= 255) {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "URL may not contain more than 255 characters";
      document.getElementById('message1').style.display = "none";
    }
    else if (textData == "") {
      document.getElementById('message1').style.display = "block";
      document.getElementById('message1').textContent = "You can't leave this blank.";
      document.getElementById('message').style.display = "none";
    }
    else if ((urlData.substring(0, 8).toUpperCase() == "HTTPS://") || (urlData.substring(0, 7).toUpperCase() == "HTTP://")) {
      document.getElementById('message').style.display = "none";
      document.getElementById('message1').style.display = "none";

      await sp.web.lists.getByTitle(listName).items.add({
        //data
        Url: {
          Description: textData,
          Url: urlData
        }
      }).then(i => addedID = i.data.ID).catch(e => console.log(e.message));
      //check attachment exists
      if (attachData.length != 0) {
        //add attachments
        await sp.web.lists.getByTitle(listName).items.getById(addedID).attachmentFiles.add(attachData[0].name, attachData[0]).then(
          i => {
            addedImage = "https://robertwalters.sharepoint.com" + i.data.ServerRelativeUrl;
          }).catch(e => console.log(e.message));
      }

      this.setState({ showNewPanel: false });

      if (attachData.length == 0) {
        addItem =
          {
            Url: urlData,
            Description: textData,
            AttachmentFiles: this.props.imgUrl,
            Attachments: false,
            ID: addedID.toString()
          };
      }
      else {
        addItem =
          {
            Url: urlData,
            Description: textData,
            AttachmentFiles: addedImage,
            Attachments: true,
            ID: addedID.toString()
          };
      }
      this.state.tilesArr.unshift(addItem);
      tilesNew = true;
      oldT = 0;
      valT = this.state.tilesArr.length > 4 ? 4 : this.state.tilesArr.length;
      this.disTiles();
    }
    else {
      document.getElementById('message').style.display = "block";
      document.getElementById('message').textContent = "Url must start with https://";
      document.getElementById('message1').style.display = "none";
    }
  }
  private async tilesDel(e, oldTv, valTv) {
    let needToDel: number;
    const { tilesArr } = this.state;
    //console.log('testDelID:'+e+'state.tilesA.leng'+tilesArr.length+'oldT'+oldTv+'valT'+valTv+'last'+last);console.log(tilesArr);
    for (let s = 0; s < tilesArr.length; s++) {
      if (tilesArr[s].ID == e) {
        needToDel = s;
      }
    }

    await sp.web.lists.getByTitle(listName).items.getById(parseInt(e)).delete().then(i => {
      tilesArr.splice(tilesArr.indexOf(tilesArr[needToDel]), 1);
    }).catch(er => console.log(er.message));
    if (last == 'no') {
      this.state.tilesArr.map(i => arr1.push(i));
      //console.log('last'+last+this.state.tilesArr.length+arr1.length);
      await next();
      this.setState({ tilesArr: arr1 });
      valT = valT;
      oldT = oldT;
    }
    else if (tilesArr.length >= valT) { valT = valT; oldT = oldT; }
    else {
      valT = valT - 1;
      oldT = valT % 4 == 0 ? valT - 4 : oldT;
    }
    btntilesBack = oldT <= 0 ? true : false;
    btntilesNext = last == 'yes' && valT == this.state.tilesArr.length ? true : false;
    // console.log('testDel'+'tempLast'+tempLast+'tilesArrLe'+this.state.tilesArr.length+'nextB'+btntilesNext+'backB'+btntilesBack+'tilesTemp'+tilesTemp+'last'+last+'oldT'+oldT+'valT'+valT+'arr2L'+arr2.length);
    for (let m = oldT; m < valT; m++) { arr2[m] = this.state.tilesArr[m]; }
    if (userPerm) {
      tilesAddLink = <div>
        <PrimaryButton
          onClick={this._onShowNewPanel}
          text="Add Link"
          className={panelStyle.addLink}
        /></div>;
    }
    this.setState({
      Data:
        <div>
          {tilesAddLink}
          <TilesData userPerm={userPerm} imgUrl={this.props.imgUrl} siteUrl={this.props.siteUrl} tilesDel={this.tilesDel.bind(this)} oldT={oldT} valT={valT} arr1={arr2} tilesBack={this._back.bind(this)} tilesNext={this._next.bind(this)} btntilesNext={btntilesNext} btntilesBack={btntilesBack} />
        </div>
    });
    arr1 = [];
    arr2 = [];
  }
}